import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'إدارة الطابور',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> queue = [];
  final TextEditingController nameController = TextEditingController();

  void addToQueue() {
    if (nameController.text.isEmpty) return;

    setState(() {
      int estimatedTime = (queue.length + 1) * 10; // كل عميل يأخذ 10 دقائق تقريبًا
      queue.add({"name": nameController.text, "time": estimatedTime});
      nameController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("إدارة الطابور")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: "أدخل اسمك", border: OutlineInputBorder()),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: addToQueue,
              child: Text("حجز دور"),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: queue.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(queue[index]["name"]),
                    subtitle: Text("وقت الانتظار التقريبي: ${queue[index]["time"]} دقيقة"),
                    leading: CircleAvatar(child: Text("${index + 1}")),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
